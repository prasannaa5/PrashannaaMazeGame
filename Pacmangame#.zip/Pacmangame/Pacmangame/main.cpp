#include "PacmanGame.h"

int main() {
    PacmanGame game;
    game.run();
    return 0;
}
